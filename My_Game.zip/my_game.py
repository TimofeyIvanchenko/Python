from hamsters import Hamster
from player import Player

hamsters_count = 4


class Game:
    directions = {"w": "s", "s": "w", "a": "d", "d": "a"}
    happy_message = "\tWOW!!! You won!!!"
    map = """****\n****\n****\n****"""
    gameon = True

    def __init__(self):
        self.player = Player()
        self.hamsters = []
        for i in range(hamsters_count):
            self.hamsters.append(Hamster(i, self.get_full_map()))
        self.count = len(self.hamsters)  # баг 3 - победа игрока в концовке игры

    def add_point(self, position, name, s):
        li = s.split("\n")
        row = li[position[1]]
        row = row[:position[0]] + name + row[position[0] + 1:]
        li[position[1]] = row
        return "\n".join(li)

    def render_map(self):
        s = self.map
        s = self.add_point(self.player.position, "x", s)
        for h in self.hamsters:
            if h.health > 0:
                s = self.add_point(h.position, str(h.hid + 1), s)
        print(s)

    def move_player(self, destination):
        if destination == "s":  # баг 1 - выход игрока за границы поля
            if self.player.position[1] == len(self.map.split("\n")) - 1:
                return False
            self.player.position[1] += 1
        elif destination == "w":  # баг 1 - выход игрока за границы поля
            if self.player.position[1] == 0:
                return False
            self.player.position[1] -= 1
        elif destination == "a":  # баг 1 - выход игрока за границы поля
            if self.player.position[0] == 0:
                return False
            self.player.position[0] -= 1
        elif destination == "d":  # баг 1 - выход игрока за границы поля
            if self.player.position[0] == len(self.map.split("\n")[0]) - 1:
                return False
            self.player.position[0] += 1
        self.on_move(destination)

    def get_full_map(self):
        s = self.map
        s = self.add_point(self.player.position, "x", s)  # баг 2 - появление игрока на одной и той же позиции с хомяком
        for h in self.hamsters:
            s = self.add_point(h.position, str(h.hid + 1), s)
        return s

    def get_hamster_on_position(self, coords):
        s = self.get_full_map()
        return s.split("\n")[coords[1]][coords[0]]

    def on_move(self, direction):
        hamster = self.get_hamster_on_position(self.player.position)
        if hamster not in {"*", "x"}:
            self.player.was_hit(int(hamster))
            if self.player.health <= 0:
                self.gameon = False
                print("\tGAME OVER ! Hamsters won !!!")
                return False
            print("Player health: {}".format(self.player.health))
            killed = self.hamsters[int(hamster) - 1].on_shot()
            if not killed:
                print("Hamster", self.hamsters[int(hamster) - 1].hid + 1, ": not killed")
                self.move_player(self.directions[direction])
            else:
                print("Hamster", self.hamsters[int(hamster) - 1].hid + 1, ": was killed !!!")
                self.count -= 1

    def start(self):
        self.render_map()
        while self.gameon:
            if self.count == 0:  # баг 3 - победа игрока в концовке игры
                print(self.happy_message)
                break
            command = input("Insert command: ")
            if command in ["a", "s", "d", "w"]:
                self.move_player(command)
                self.render_map()
            elif command == "q":
                print("\tGAME OVER !!!")
                self.gameon = False
            elif command == "e":
                self.player.wait()


game = Game()
game.start()

# баг 1 - выход игрока за границы поля
# баг 2 - появление игрока на одной и той же позиции с хомяком
# баг 3 - победа игрока в концовке игры
# дополнительный баг - теперь игрок всегда появляется в начальной точке (0,0)

# неисправленный баг - после того, как хомяк убит, на карте хомяк исчезает,
# но игрок продолжает убивать в той же позиции ранее уже убитого хомяка 
# к сожалению, не успел исправить т.к. время ограничено
