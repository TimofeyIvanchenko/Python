from random import randint


class Player:
    health = 10
    max_health = 10
    default_damage = 10
    position = [0, 0]  # дополнительный баг - теперь игрок появляется в начальной точке (0,0)

    def was_hit(self, hid):
        self.health -= randint(0, hid)
        return self.health <= 0

    def wait(self):
        if self.health < self.max_health:
            self.health += 1
        print("Player health: {}".format(self.health))
